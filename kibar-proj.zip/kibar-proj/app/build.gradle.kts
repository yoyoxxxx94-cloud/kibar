plugins {
    id("com.android.application")
}

android {
    namespace = "app.kibar"
    compileSdk = 34
    buildFeatures { buildConfig = true }

    defaultConfig {
        applicationId = "app.kibar"
        minSdk = 26
        targetSdk = 34
        versionCode = (project.findProperty("appVersionCode") as String? ?: "1").toInt()
        versionName = "1.0"
        buildConfigField("String", "REPO", "\"yoyoxxxx94-cloud/kibar\"")
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
    implementation("androidx.webkit:webkit:1.11.0")
}
