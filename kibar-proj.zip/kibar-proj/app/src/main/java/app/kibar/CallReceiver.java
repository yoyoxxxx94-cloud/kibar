package app.kibar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.telephony.TelephonyManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

public class CallReceiver extends BroadcastReceiver {
    private static long lastAt = 0;
    private static String lastNum = "";

    static String tail(String s) {
        String d = s == null ? "" : s.replaceAll("[^0-9]", "");
        return d.length() > 9 ? d.substring(d.length() - 9) : d;
    }

    @Override
    public void onReceive(final Context ctx, Intent intent) {
        try {
            if (!TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(intent.getAction())) return;
            String st = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
            if (!TelephonyManager.EXTRA_STATE_RINGING.equals(st)) return;
            String num = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
            if (num == null || num.length() == 0) return;
            long now = System.currentTimeMillis();
            if (tail(num).equals(lastNum) && now - lastAt < 20000) return;
            SharedPreferences sp = ctx.getSharedPreferences("kibar", Context.MODE_PRIVATE);
            String mode = sp.getString("callMode", "2");
            if (mode.equals("1")) return;
            String gender = sp.getString("callGender", "f");
            JSONArray arr = new JSONArray(sp.getString("callPeople", "[]"));
            String name = null;
            boolean photo = false;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (tail(o.optString("n")).equals(tail(num)) && tail(num).length() >= 7) {
                    name = o.optString("name");
                    photo = o.optBoolean("photo");
                    break;
                }
            }
            if (name == null || name.length() == 0) return;
            if (mode.equals("2") && photo) return;
            lastNum = tail(num);
            lastAt = now;
            final String say = name + " يتصل بك";
            final boolean male = "m".equals(gender);
            final Context app = ctx.getApplicationContext();
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override public void run() { speak(app, say, male); }
            }, 2500);
        } catch (Exception e) { }
    }

    private void speak(Context app, final String text, final boolean male) {
        final TextToSpeech[] holder = new TextToSpeech[1];
        holder[0] = new TextToSpeech(app, new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                try {
                    TextToSpeech t = holder[0];
                    if (status != TextToSpeech.SUCCESS || t == null) return;
                    t.setLanguage(new Locale("ar"));
                    t.setPitch(male ? 0.75f : 1.1f);
                    t.setSpeechRate(0.9f);
                    t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "callname");
                    t.speak(text, TextToSpeech.QUEUE_ADD, null, "callname2");
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override public void run() { try { holder[0].shutdown(); } catch (Exception e) { } }
                    }, 9000);
                } catch (Exception e) { }
            }
        });
    }
}
