package app.kibar;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.speech.tts.TextToSpeech;
import android.widget.Toast;
import java.util.Locale;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 1;
    private static final int REQ_PERM = 2;
    private static final int REQ_CALL = 3;
    private static final String HOME_URL = "https://appassets.androidplatform.net/assets/index.html";

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraUri;
    private String pendingCall;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @SuppressWarnings("deprecation")
    private void hideNav() {
        try {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        } catch (Exception ignored) { }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideNav();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);
        try {
            getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
                @Override public void onSystemUiVisibilityChange(int v) {
                    if ((v & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) == 0) {
                        ui.postDelayed(new Runnable() { @Override public void run() { hideNav(); } }, 1500);
                    }
                }
            });
        } catch (Exception ignored) { }
        hideNav();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent;
                    if (params.isCaptureEnabled()) {
                        File dir = new File(getCacheDir(), "photos");
                        dir.mkdirs();
                        File f = File.createTempFile("pic_", ".jpg", dir);
                        cameraUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                        intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        intent.setClipData(ClipData.newRawUri("", cameraUri));
                    } else {
                        cameraUri = null;
                        boolean img = false;
                        String[] acc = params.getAcceptTypes();
                        if (acc != null) {
                            for (String a : acc) if (a != null && a.startsWith("image")) img = true;
                        }
                        intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType(img ? "image/*" : "*/*");
                    }
                    startActivityForResult(intent, REQ_FILE);
                    return true;
                } catch (Exception e) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    return false;
                }
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(HOME_URL);

        askStartupPermissions();
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int r = tts.setLanguage(new Locale("ar"));
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(new Locale("ar", "SA"));
                    ttsReady = true;
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    private void askStartupPermissions() {
        if (Build.VERSION.SDK_INT < 23) return;
        java.util.ArrayList<String> need = new java.util.ArrayList<String>();
        String[] all = {Manifest.permission.CALL_PHONE, Manifest.permission.READ_SMS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS};
        for (String p : all) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_CALL) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && pendingCall != null) {
                doCall(pendingCall);
            } else if (pendingCall != null) {
                dial(pendingCall);
            }
            pendingCall = null;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != REQ_FILE || filePathCallback == null) {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }
        Uri[] results = null;
        if (resultCode == RESULT_OK) {
            if (cameraUri != null) results = new Uri[]{cameraUri};
            else if (data != null && data.getData() != null) results = new Uri[]{data.getData()};
        }
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
        cameraUri = null;
    }

    @Override
    public void onBackPressed() {
        // لا نغلق التطبيق بزر الرجوع: الصفحة تتولى الرجوع بنفسها
        if (web != null) web.evaluateJavascript("window.__back&&window.__back()", null);
    }

    private void unpinNow() {
        try { stopLockTask(); } catch (Exception ignored) { }
    }

    private String clean(String n) {
        String d = n == null ? "" : n.replaceAll("[^0-9+]", "");
        return d;
    }

    private void dial(String num) {
        try {
            startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + clean(num))));
        } catch (Exception e) {
            Toast.makeText(this, "تعذر الاتصال", Toast.LENGTH_LONG).show();
        }
    }

    private void doCall(String num) {
        try {
            startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + clean(num))));
        } catch (SecurityException e) {
            dial(num);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر الاتصال", Toast.LENGTH_LONG).show();
        }
    }

    private void speaker(boolean on) {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            am.setMode(AudioManager.MODE_IN_COMMUNICATION);
            am.setSpeakerphoneOn(on);
        } catch (Exception ignored) { }
    }

    private void js(final String code) {
        runOnUiThread(new Runnable() {
            @Override public void run() { if (web != null) web.evaluateJavascript(code, null); }
        });
    }

    private int versionCode() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Exception e) { return 0; }
    }

    private String http(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("User-Agent", "kibar-app");
        InputStream in = c.getInputStream();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[4096];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        in.close();
        return o.toString("UTF-8");
    }

    private void doUpdate(final boolean install) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    js("window.__upd&&window.__upd('check','')");
                    String body = http("https://api.github.com/repos/" + BuildConfig.REPO + "/releases/tags/latest");
                    JSONObject r = new JSONObject(body);
                    String notes = r.optString("body", "");
                    int remote = 0;
                    java.util.regex.Matcher m = java.util.regex.Pattern.compile("vc=(\\d+)").matcher(notes);
                    if (m.find()) remote = Integer.parseInt(m.group(1));
                    int local = versionCode();
                    if (remote <= local) {
                        js("window.__upd&&window.__upd('none','')");
                        return;
                    }
                    String apkUrl = null;
                    JSONArray as = r.optJSONArray("assets");
                    if (as != null) {
                        for (int i = 0; i < as.length(); i++) {
                            JSONObject a = as.getJSONObject(i);
                            if (a.optString("name").endsWith(".apk")) apkUrl = a.optString("browser_download_url");
                        }
                    }
                    if (apkUrl == null) { js("window.__upd&&window.__upd('err','')"); return; }
                    if (!install) { js("window.__upd&&window.__upd('new','')"); return; }

                    js("window.__upd&&window.__upd('down','')");
                    File dir = new File(getCacheDir(), "update");
                    dir.mkdirs();
                    File f = new File(dir, "app.apk");
                    HttpURLConnection c = (HttpURLConnection) new URL(apkUrl).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(30000);
                    c.setInstanceFollowRedirects(true);
                    InputStream in = c.getInputStream();
                    FileOutputStream out = new FileOutputStream(f);
                    byte[] b = new byte[8192];
                    int n;
                    while ((n = in.read(b)) > 0) out.write(b, 0, n);
                    out.close();
                    in.close();
                    final Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            try {
                                if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                                    Toast.makeText(MainActivity.this, "فعّل «السماح بالتثبيت» ثم ارجع واضغط تحديث مرة ثانية", Toast.LENGTH_LONG).show();
                                    startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                            Uri.parse("package:" + getPackageName())));
                                    js("window.__upd&&window.__upd('perm','')");
                                    return;
                                }
                                Intent i = new Intent(Intent.ACTION_VIEW);
                                i.setDataAndType(uri, "application/vnd.android.package-archive");
                                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(i);
                                js("window.__upd&&window.__upd('install','')");
                            } catch (Exception e) {
                                js("window.__upd&&window.__upd('err','')");
                            }
                        }
                    });
                } catch (Exception e) {
                    js("window.__upd&&window.__upd('err','')");
                }
            }
        }).start();
    }

    private void doSpeak(final String text, final String gender, final double rate, final String voiceName) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    if (!ttsReady) { Toast.makeText(MainActivity.this, "النطق غير جاهز، حاول بعد لحظات", Toast.LENGTH_SHORT).show(); return; }
                    tts.setSpeechRate((float) (rate > 0 ? rate : 0.9));
                    boolean chosen = false;
                    try {
                        java.util.Set<android.speech.tts.Voice> vs = tts.getVoices();
                        if (vs != null) {
                            if (voiceName != null && voiceName.length() > 0) {
                                for (android.speech.tts.Voice v : vs) {
                                    if (v.getName().equals(voiceName)) { tts.setVoice(v); chosen = true; break; }
                                }
                            } else {
                                android.speech.tts.Voice pick = null;
                                for (android.speech.tts.Voice v : vs) {
                                    if (v.getLocale() != null && "ar".equals(v.getLocale().getLanguage()) && !v.isNetworkConnectionRequired()) {
                                        if (pick == null) pick = v;
                                    }
                                }
                                if (pick != null) tts.setVoice(pick);
                            }
                        }
                    } catch (Exception ignored) { }
                    if (chosen) tts.setPitch(1.0f);
                    else tts.setPitch("m".equals(gender) ? 0.7f : 1.15f);
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kibar");
                } catch (Exception ignored) { }
            }
        });
    }

    /** الدوال التي تستدعيها الصفحة: window.Android.* */
    private class Bridge {

        @JavascriptInterface
        public boolean has() { return true; }

        @JavascriptInterface
        public void speak(final String text, final String gender, final double rate) {
            doSpeak(text, gender, rate, "");
        }

        @JavascriptInterface
        public void speakWith(final String text, final String voiceName, final double rate, final String gender) {
            doSpeak(text, gender, rate, voiceName);
        }

        @JavascriptInterface
        public String getVoices() {
            JSONArray arr = new JSONArray();
            try {
                if (!ttsReady) return "[]";
                java.util.Set<android.speech.tts.Voice> vs = tts.getVoices();
                if (vs != null) {
                    java.util.ArrayList<android.speech.tts.Voice> list = new java.util.ArrayList<android.speech.tts.Voice>();
                    for (android.speech.tts.Voice v : vs) {
                        if (v.getLocale() != null && "ar".equals(v.getLocale().getLanguage())) list.add(v);
                    }
                    java.util.Collections.sort(list, new java.util.Comparator<android.speech.tts.Voice>() {
                        @Override public int compare(android.speech.tts.Voice x, android.speech.tts.Voice y) {
                            return x.getName().compareTo(y.getName());
                        }
                    });
                    for (android.speech.tts.Voice v : list) {
                        JSONObject o = new JSONObject();
                        o.put("name", v.getName());
                        o.put("network", v.isNetworkConnectionRequired());
                        arr.put(o);
                    }
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface
        public void stopSpeak() {
            runOnUiThread(new Runnable() {
                @Override public void run() { try { if (tts != null) tts.stop(); } catch (Exception ignored) { } }
            });
        }

        @JavascriptInterface
        public void call(final String number) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    unpinNow();
                    if (Build.VERSION.SDK_INT >= 23
                            && checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        pendingCall = number;
                        requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, REQ_CALL);
                    } else {
                        doCall(number);
                    }
                }
            });
        }

        @JavascriptInterface
        public void videoCall(final String number, final String name) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    unpinNow();
                    try {
                        String n = clean(number);
                        if (n.startsWith("00")) n = n.substring(2);
                        else if (n.startsWith("0")) n = "966" + n.substring(1);
                        else if (n.startsWith("+")) n = n.substring(1);
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + n));
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "واتساب غير مثبّت", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void setSpeaker(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    speaker(on);
                    // المكالمة تتصل بعد ثوانٍ، فنكرر التشغيل عدة مرات
                    if (on) {
                        int[] t = {1500, 3500, 6500, 10000};
                        for (int d : t) ui.postDelayed(new Runnable() {
                            @Override public void run() { speaker(true); }
                        }, d);
                    } else {
                        try {
                            ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).setMode(AudioManager.MODE_NORMAL);
                        } catch (Exception ignored) { }
                    }
                }
            });
        }

        @JavascriptInterface
        public String getSms() {
            JSONArray arr = new JSONArray();
            try {
                if (Build.VERSION.SDK_INT >= 23
                        && checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                    return "[]";
                }
                Cursor c = getContentResolver().query(Uri.parse("content://sms/inbox"),
                        new String[]{"_id", "address", "body", "date"}, null, null, "date DESC LIMIT 40");
                if (c != null) {
                    while (c.moveToNext()) {
                        JSONObject o = new JSONObject();
                        o.put("id", "s" + c.getString(0));
                        o.put("from", c.getString(1));
                        o.put("body", c.getString(2));
                        o.put("date", c.getLong(3));
                        arr.put(o);
                    }
                    c.close();
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface
        public boolean isInstalled(String pkg) {
            try { getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public boolean openApp(final String pkg) {
            try {
                final Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i == null) return false;
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        unpinNow();
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override public void run() { try { startActivity(i); } catch (Exception ignored) { } }
                        }, 350);
                    }
                });
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public void unpinScreen() {
            runOnUiThread(new Runnable() { @Override public void run() { unpinNow(); } });
        }

        @JavascriptInterface
        public String getAppIcon(String pkg) {
            try {
                Drawable d = getPackageManager().getApplicationIcon(pkg);
                int sz = 160;
                Bitmap bm = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
                Canvas cv = new Canvas(bm);
                d.setBounds(0, 0, sz, sz);
                d.draw(cv);
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.PNG, 100, o);
                return "data:image/png;base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    unpinNow();
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public boolean isOnline() {
            try {
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
                return nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public void openInternet() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    unpinNow();
                    try {
                        if (Build.VERSION.SDK_INT >= 29) startActivity(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY));
                        else startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                    } catch (Exception e) {
                        try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); } catch (Exception ignored) { }
                    }
                }
            });
        }

        @JavascriptInterface
        public String getContacts() {
            JSONArray out = new JSONArray();
            try {
                if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(new Runnable() { @Override public void run() {
                        requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_PERM);
                    } });
                    return "[]";
                }
                Cursor c = getContentResolver().query(
                    android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                                 android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER},
                    null, null,
                    android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC");
                if (c != null) {
                    java.util.HashSet<String> seen = new java.util.HashSet<String>();
                    while (c.moveToNext() && out.length() < 3000) {
                        String name = c.getString(0);
                        String num = c.getString(1);
                        if (name == null || num == null) continue;
                        String key = num.replaceAll("[^0-9+]", "");
                        if (key.length() == 0 || !seen.add(name + "|" + key)) continue;
                        JSONArray row = new JSONArray();
                        row.put(name);
                        row.put(num.replaceAll("[\\s-]", ""));
                        out.put(row);
                    }
                    c.close();
                }
            } catch (Exception e) { }
            return out.toString();
        }

        @JavascriptInterface
        public void setCallAnnounce(String mode, String gender, String peopleJson) {
            try {
                getSharedPreferences("kibar", Context.MODE_PRIVATE).edit()
                    .putString("callMode", mode).putString("callGender", gender)
                    .putString("callPeople", peopleJson).apply();
            } catch (Exception e) { }
        }

        @JavascriptInterface
        public void saveText(final String name, final String text) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        byte[] data = text.getBytes("UTF-8");
                        if (Build.VERSION.SDK_INT >= 29) {
                            ContentValues v = new ContentValues();
                            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                            OutputStream o = getContentResolver().openOutputStream(uri);
                            o.write(data);
                            o.close();
                        } else {
                            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                            dir.mkdirs();
                            FileOutputStream o = new FileOutputStream(new File(dir, name));
                            o.write(data);
                            o.close();
                        }
                        Toast.makeText(MainActivity.this, "تم الحفظ في مجلد التنزيلات (Download)", Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "تعذر حفظ الملف", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void setHome() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try { startActivity(new Intent(Settings.ACTION_HOME_SETTINGS)); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "افتح إعدادات الجوال ثم التطبيقات الافتراضية", Toast.LENGTH_LONG).show(); }
                }
            });
        }

        @JavascriptInterface
        public void pinScreen() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                        if (Build.VERSION.SDK_INT >= 23 && am != null
                            && am.getLockTaskModeState() != android.app.ActivityManager.LOCK_TASK_MODE_NONE) return;
                        startLockTask();
                    } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void setAdhan(String json) {
            AdhanScheduler.replaceAll(MainActivity.this, json);
        }

        @JavascriptInterface
        public void testAdhan() {
            try {
                Intent s = new Intent(MainActivity.this, AdhanService.class);
                s.putExtra("name", "المغرب");
                s.putExtra("at", System.currentTimeMillis() + 6000);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public String adhanStatus() {
            try {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return "notif";
                if (Build.VERSION.SDK_INT >= 31) {
                    android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    if (!am.canScheduleExactAlarms()) return "exact";
                }
                android.os.PowerManager pm = (android.os.PowerManager) getSystemService(Context.POWER_SERVICE);
                if (Build.VERSION.SDK_INT >= 23 && !pm.isIgnoringBatteryOptimizations(getPackageName())) return "battery";
            } catch (Exception ignored) { }
            return "";
        }

        @JavascriptInterface
        public void adhanPerms() {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    String st = new Bridge().adhanStatus();
                    if ("notif".equals(st)) {
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77);
                    } else if ("exact".equals(st)) {
                        Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                        i.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    } else if ("battery".equals(st)) {
                        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                        i.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    }
                } catch (Exception ignored) { }
            } });
        }

        @JavascriptInterface
        public void exitToHome() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try { stopLockTask(); } catch (Exception ignored) { }
                    moveTaskToBack(true);
                }
            });
        }

        @JavascriptInterface
        public int appVersion() { return versionCode(); }

        @JavascriptInterface
        public void checkUpdate() { doUpdate(false); }

        @JavascriptInterface
        public void installUpdate() { doUpdate(true); }
    }
}
