package app.kibar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

public class AdhanScheduler {
    static final long LEAD = 9000; // يبدأ النطق قبل الأذان بنحو 9 ثوانٍ

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("kibar_adhan", Context.MODE_PRIVATE); }

    static PendingIntent pi(Context c, String id, String name, long at) {
        Intent i = new Intent(c, AdhanReceiver.class);
        i.setAction("app.kibar.ADHAN");
        i.setData(Uri.parse("adhan://" + id));
        i.putExtra("name", name);
        i.putExtra("at", at);
        return PendingIntent.getBroadcast(c, id.hashCode(), i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void cancelAll(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            JSONArray old = new JSONArray(sp(c).getString("list", "[]"));
            for (int k = 0; k < old.length(); k++) {
                JSONObject o = old.getJSONObject(k);
                am.cancel(pi(c, o.getString("id"), o.optString("name"), o.optLong("at")));
            }
        } catch (Exception ignored) { }
    }

    static void schedule(Context c, JSONArray list) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            long now = System.currentTimeMillis();
            boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            for (int k = 0; k < list.length(); k++) {
                JSONObject o = list.getJSONObject(k);
                long at = o.getLong("at");
                long fire = at - LEAD;
                if (at < now + 1000) continue;
                if (fire < now + 500) fire = now + 500;
                PendingIntent p = pi(c, o.getString("id"), o.optString("name"), at);
                try {
                    if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fire, p);
                    else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fire, p);
                } catch (SecurityException e) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fire, p);
                }
            }
        } catch (Exception ignored) { }
    }

    static void replaceAll(Context c, String json) {
        try {
            cancelAll(c);
            JSONArray list = new JSONArray(json);
            sp(c).edit().putString("list", list.toString()).apply();
            schedule(c, list);
        } catch (Exception ignored) { }
    }

    static void rescheduleAll(Context c) {
        try { schedule(c, new JSONArray(sp(c).getString("list", "[]"))); } catch (Exception ignored) { }
    }
}
