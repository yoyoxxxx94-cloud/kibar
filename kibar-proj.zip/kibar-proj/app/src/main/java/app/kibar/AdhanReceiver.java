package app.kibar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AdhanReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            String a = intent.getAction();
            if ("app.kibar.ADHAN".equals(a)) {
                Intent s = new Intent(ctx, AdhanService.class);
                s.putExtra("name", intent.getStringExtra("name"));
                s.putExtra("at", intent.getLongExtra("at", 0));
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(s); else ctx.startService(s);
            } else {
                AdhanScheduler.rescheduleAll(ctx);
            }
        } catch (Exception ignored) { }
    }
}
