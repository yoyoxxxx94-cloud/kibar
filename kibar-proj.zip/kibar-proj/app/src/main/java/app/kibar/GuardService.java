package app.kibar;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.view.MotionEvent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class GuardService extends AccessibilityService {
    static volatile boolean running = false;
    private static final Pattern BAD = Pattern.compile(
        "recent|overview|notificationshade|notificationpanel|notification_panel|quicksetting|statusbarwindow|taskswitcher|multitask",
        Pattern.CASE_INSENSITIVE);
    private long last = 0;
    private String homePkg = null;

    private String launcherPkg() {
        if (homePkg != null) return homePkg;
        try {
            Intent h = new Intent(Intent.ACTION_MAIN);
            h.addCategory(Intent.CATEGORY_HOME);
            android.content.pm.ResolveInfo ri = getPackageManager().resolveActivity(h, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
            homePkg = (ri != null && ri.activityInfo != null) ? ri.activityInfo.packageName : "";
        } catch (Exception e) { homePkg = ""; }
        return homePkg;
    }
    private final ArrayList<View> cover = new ArrayList<View>();

    private static boolean isTikTok(String p) {
        return p.equals("com.zhiliaoapp.musically") || p.equals("com.ss.android.ugc.trill");
    }

    private void addCover(View v, int w, int h, int gx, int gy, int fmt) {
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            fmt);
        lp.gravity = gx | gy;
        lp.y = nextY;
        nextY = 0;
        wm.addView(v, lp);
        cover.add(v);
    }

    private View block() {
        View v = new View(this);
        v.setBackgroundColor(Color.BLACK);
        v.setClickable(true);
        return v;
    }

    private int sw = 1080, sh = 2400, nextY = 0;

    private void swipe(boolean up) {
        try {
            Path path = new Path();
            float x = sw / 2f;
            if (up) { path.moveTo(x, sh * 0.65f); path.lineTo(x, sh * 0.35f); }
            else { path.moveTo(x, sh * 0.35f); path.lineTo(x, sh * 0.65f); }
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(new GestureDescription.StrokeDescription(path, 0, 220));
            dispatchGesture(b.build(), null, null);
        } catch (Exception ignored) { }
    }

    // transparent: video and buttons stay visible, but touches do nothing; vertical swipes are passed on
    private View soft() {
        View v = new View(this);
        v.setBackgroundColor(Color.TRANSPARENT);
        v.setClickable(true);
        v.setOnTouchListener(new View.OnTouchListener() {
            float dx0, dy0;
            @Override public boolean onTouch(View view, MotionEvent e) {
                int a = e.getAction();
                if (a == MotionEvent.ACTION_DOWN) { dx0 = e.getRawX(); dy0 = e.getRawY(); }
                else if (a == MotionEvent.ACTION_UP) {
                    float dx = e.getRawX() - dx0, dy = e.getRawY() - dy0;
                    if (Math.abs(dy) > sh * 0.05f && Math.abs(dy) > Math.abs(dx)) swipe(dy < 0);
                }
                return true;
            }
        });
        return v;
    }

    private void showCover() {
        if (!cover.isEmpty()) return;
        try {
            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            int W = dm.widthPixels, H = dm.heightPixels;
            sw = W; sh = H;
            int top = (int) (H * 0.125f), bottom = (int) (H * 0.13f), side = (int) (W * 0.21f);
                        addCover(block(), W, top, Gravity.LEFT, Gravity.TOP, PixelFormat.OPAQUE);
            addCover(block(), W, bottom, Gravity.LEFT, Gravity.BOTTOM, PixelFormat.OPAQUE);
            nextY = (int) (H * 0.34f);
            addCover(soft(), side, (int) (H * 0.36f), Gravity.LEFT | Gravity.TOP, Gravity.NO_GRAVITY, PixelFormat.TRANSLUCENT);
            nextY = (int) (H * 0.34f);
            addCover(soft(), side, (int) (H * 0.36f), Gravity.RIGHT | Gravity.TOP, Gravity.NO_GRAVITY, PixelFormat.TRANSLUCENT);
            nextY = (int) (H * 0.70f);
            addCover(soft(), W, (int) (H * 0.17f), Gravity.LEFT | Gravity.TOP, Gravity.NO_GRAVITY, PixelFormat.TRANSLUCENT);
            int s = (int) (W * 0.15f);
            TextView x = new TextView(this);
            x.setText("\u2715");
            x.setTextColor(Color.WHITE);
            x.setTextSize(28);
            x.setTypeface(Typeface.DEFAULT_BOLD);
            x.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(0xFFC62828);
            x.setBackground(g);
            x.setClickable(true);
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { leaveToApp(); }
            });
            addCover(x, s, s, Gravity.LEFT | Gravity.TOP, Gravity.NO_GRAVITY, PixelFormat.TRANSLUCENT);
        } catch (Exception e) {
            hideCover();
        }
    }

    private void hideCover() {
        try {
            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            for (View v : cover) { try { wm.removeView(v); } catch (Exception ignored) { } }
        } catch (Exception ignored) { }
        cover.clear();
    }

    private void leaveToApp() {
        hideCover();
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        } catch (Exception ignored) { }
    }

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (!cover.isEmpty() && event.getKeyCode() == KeyEvent.KEYCODE_BACK) return true;
        return super.onKeyEvent(event);
    }

    @Override
    protected void onServiceConnected() {
        running = true;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        running = false;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    @Override
    public void onInterrupt() { }

    private void log(SharedPreferences sp, String line) {
        try {
            String old = sp.getString("guardLog", "");
            if (old.endsWith(line)) return;
            String[] parts = old.length() == 0 ? new String[0] : old.split("\n");
            StringBuilder sb = new StringBuilder();
            int from = Math.max(0, parts.length - 7);
            for (int i = from; i < parts.length; i++) sb.append(parts[i]).append("\n");
            sb.append(line);
            sp.edit().putString("guardLog", sb.toString()).apply();
        } catch (Exception ignored) { }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent ev) {
        try {
            if (ev == null || ev.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
            CharSequence pk = ev.getPackageName();
            CharSequence cn = ev.getClassName();
            String p = pk == null ? "" : pk.toString();
            String c = cn == null ? "" : cn.toString();
            if (p.equals(getPackageName())) { hideCover(); return; }
            SharedPreferences sp = getSharedPreferences("kibar", Context.MODE_PRIVATE);
            if (!p.startsWith("com.google.android.inputmethod") && p.indexOf("keyboard") < 0) {
                log(sp, p + "|" + c);
            }
            if (!sp.getBoolean("guardOn", false)) { hideCover(); return; }
            if (isTikTok(p)) { showCover(); return; }
            if (!cover.isEmpty() && !p.equals("com.android.systemui") && !p.equals("android")
                && !p.startsWith("com.google.android.inputmethod") && p.indexOf("keyboard") < 0
                && !p.equals("com.google.android.permissioncontroller") && !p.equals("com.android.permissioncontroller")) {
                leaveToApp();
                return;
            }
            boolean home = p.equals(launcherPkg()) || p.equals("com.android.launcher") || p.equals("com.android.launcher3");
            if (!home && !BAD.matcher(c).find() && p.toLowerCase().indexOf("recent") < 0) return;
            long now = System.currentTimeMillis();
            if (now - last < 1200) return;
            last = now;
            if (!home) performGlobalAction(GLOBAL_ACTION_HOME);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(GuardService.this, MainActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(i);
                    } catch (Exception ignored) { }
                }
            }, 250);
        } catch (Exception ignored) { }
    }
}
