package app.kibar;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import java.util.regex.Pattern;

public class GuardService extends AccessibilityService {
    static volatile boolean running = false;
    private static final Pattern BAD = Pattern.compile(
        "recent|overview|notificationshade|notificationpanel|notification_panel|quicksetting|statusbarwindow|taskswitcher|multitask",
        Pattern.CASE_INSENSITIVE);
    private long last = 0;

    @Override
    protected void onServiceConnected() {
        running = true;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        running = false;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    @Override
    public void onInterrupt() { }

    private void log(SharedPreferences sp, String line) {
        try {
            String old = sp.getString("guardLog", "");
            if (old.endsWith(line)) return;
            String[] parts = old.length() == 0 ? new String[0] : old.split("\n");
            StringBuilder sb = new StringBuilder();
            int from = Math.max(0, parts.length - 7);
            for (int i = from; i < parts.length; i++) sb.append(parts[i]).append("\n");
            sb.append(line);
            sp.edit().putString("guardLog", sb.toString()).apply();
        } catch (Exception ignored) { }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent ev) {
        try {
            if (ev == null || ev.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
            CharSequence pk = ev.getPackageName();
            CharSequence cn = ev.getClassName();
            String p = pk == null ? "" : pk.toString();
            String c = cn == null ? "" : cn.toString();
            if (p.equals(getPackageName())) return;
            SharedPreferences sp = getSharedPreferences("kibar", Context.MODE_PRIVATE);
            if (!p.startsWith("com.google.android.inputmethod") && p.indexOf("keyboard") < 0) {
                log(sp, p + "|" + c);
            }
            if (!sp.getBoolean("guardOn", false)) return;
            if (!BAD.matcher(c).find() && p.toLowerCase().indexOf("recent") < 0) return;
            long now = System.currentTimeMillis();
            if (now - last < 1200) return;
            last = now;
            performGlobalAction(GLOBAL_ACTION_HOME);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(GuardService.this, MainActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(i);
                    } catch (Exception ignored) { }
                }
            }, 250);
        } catch (Exception ignored) { }
    }
}
