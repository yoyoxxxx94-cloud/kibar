package app.kibar;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.Locale;

public class AdhanService extends Service {
    private TextToSpeech tts;
    private MediaPlayer mp;
    private PowerManager.WakeLock wl;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean started = false;
    private long at = 0;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (started) return START_NOT_STICKY;
        started = true;
        String name = intent != null ? intent.getStringExtra("name") : "";
        at = intent != null ? intent.getLongExtra("at", 0) : 0;
        if (name == null) name = "";
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel("adhan", "الأذان", NotificationManager.IMPORTANCE_LOW);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
                b = new Notification.Builder(this, "adhan");
            } else b = new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("حان وقت أذان " + name).setOngoing(true);
            if (Build.VERSION.SDK_INT >= 29) startForeground(7101, b.build(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(7101, b.build());
        } catch (Exception ignored) { }
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kibar:adhan");
            wl.acquire(120000);
        } catch (Exception ignored) { }

        final String text = "حان الآن موعد أذان " + name;
        // احتياط: إن تعذر النطق يبدأ الأذان في وقته
        h.postDelayed(new Runnable() { @Override public void run() { play(); } }, Math.max(1500, (at - System.currentTimeMillis())) + 2500);
        try {
            tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                @Override public void onInit(int status) {
                    if (status != TextToSpeech.SUCCESS) return;
                    try {
                        int r = tts.setLanguage(new Locale("ar"));
                        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(new Locale("ar", "SA"));
                        tts.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                            @Override public void onStart(String id) { }
                            @Override public void onError(String id) { }
                            @Override public void onDone(String id) {
                                long wait = Math.max(300, at - System.currentTimeMillis());
                                h.postDelayed(new Runnable() { @Override public void run() { play(); } }, wait);
                            }
                        });
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "adhan");
                    } catch (Exception ignored) { }
                }
            });
        } catch (Exception ignored) { }
        return START_NOT_STICKY;
    }

    private boolean playing = false;

    private void play() {
        if (playing) return;
        playing = true;
        try {
            mp = MediaPlayer.create(this, R.raw.adhan);
            if (mp == null) { finish(); return; }
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override public void onCompletion(MediaPlayer m) { finish(); }
            });
            mp.start();
        } catch (Exception e) { finish(); }
    }

    private void finish() {
        try { stopForeground(true); } catch (Exception ignored) { }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        try { if (mp != null) { mp.release(); mp = null; } } catch (Exception ignored) { }
        try { if (tts != null) { tts.stop(); tts.shutdown(); tts = null; } } catch (Exception ignored) { }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
