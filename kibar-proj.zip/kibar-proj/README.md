# اتصال كبار السن
ارفع محتوى هذا المجلد إلى مستودع GitHub عام باسم kibar. الملف `.github/workflows/build.yml` يُنشأ يدويًا.
